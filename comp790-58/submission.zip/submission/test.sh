#!/bin/bash
make && cd ./Exe && ./segmentDist
