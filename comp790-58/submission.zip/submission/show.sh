#!/bin/bash
~/work/Menge/Exe/menge -p ./Exe/bottleneck.xml
